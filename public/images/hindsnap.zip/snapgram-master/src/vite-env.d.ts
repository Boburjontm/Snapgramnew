

/// <reference types="vite/client" />