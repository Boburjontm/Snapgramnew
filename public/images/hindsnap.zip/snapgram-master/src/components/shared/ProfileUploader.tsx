import React from 'react'

const ProfileUploader = () => {
  return (
    <div>ProfileUploader</div>
  )
}

export default ProfileUploader